// clipboard.js

function showToast(msg) {
  const t = document.createElement('div');
  t.className = 'toast';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 2100);
}

function copyText(text) {
  if (!text) return showToast('Nothing to copy');
  navigator.clipboard.writeText(text).then(() => showToast('✅ Copied!')).catch(() => {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
    showToast('✅ Copied!');
  });
}

// Ripple effect on buttons
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
      const r = document.createElement('span');
      r.className = 'ripple';
      const rect = this.getBoundingClientRect();
      r.style.left = (e.clientX - rect.left - 100) + 'px';
      r.style.top = (e.clientY - rect.top - 100) + 'px';
      this.appendChild(r);
      setTimeout(() => r.remove(), 700);
    });
  });
});
