// utils.js — shared utility functions

// SHA helpers using SubtleCrypto
async function sha(algo, msg) {
  const enc = new TextEncoder();
  const buf = await crypto.subtle.digest(algo, enc.encode(msg));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('');
}

async function sha1(msg) { return sha('SHA-1', msg); }
async function sha256(msg) { return sha('SHA-256', msg); }
async function sha512(msg) { return sha('SHA-512', msg); }

// MD5 (pure JS)
function md5(string) {
  function safeAdd(x, y) { const lsw = (x & 0xFFFF) + (y & 0xFFFF); const msw = (x >> 16) + (y >> 16) + (lsw >> 16); return (msw << 16) | (lsw & 0xFFFF); }
  function bitRotateLeft(num, cnt) { return (num << cnt) | (num >>> (32 - cnt)); }
  function md5cmn(q, a, b, x, s, t) { return safeAdd(bitRotateLeft(safeAdd(safeAdd(a, q), safeAdd(x, t)), s), b); }
  function md5ff(a, b, c, d, x, s, t) { return md5cmn((b & c) | (~b & d), a, b, x, s, t); }
  function md5gg(a, b, c, d, x, s, t) { return md5cmn((b & d) | (c & ~d), a, b, x, s, t); }
  function md5hh(a, b, c, d, x, s, t) { return md5cmn(b ^ c ^ d, a, b, x, s, t); }
  function md5ii(a, b, c, d, x, s, t) { return md5cmn(c ^ (b | ~d), a, b, x, s, t); }
  const str = unescape(encodeURIComponent(string));
  let i, l = str.length;
  const arr = [];
  for (i = 0; i < l; i++) arr[i >> 2] |= str.charCodeAt(i) << ((i % 4) * 8);
  arr[l >> 2] |= 0x80 << ((l % 4) * 8);
  arr[(((l + 8) >> 6) << 4) + 14] = l * 8;
  let a = 1732584193, b = -271733879, c = -1732584194, d = 271733878;
  for (i = 0; i < arr.length; i += 16) {
    const oA=a, oB=b, oC=c, oD=d;
    a=md5ff(a,b,c,d,arr[i],7,-680876936); d=md5ff(d,a,b,c,arr[i+1],12,-389564586); c=md5ff(c,d,a,b,arr[i+2],17,606105819); b=md5ff(b,c,d,a,arr[i+3],22,-1044525330);
    a=md5ff(a,b,c,d,arr[i+4],7,-176418897); d=md5ff(d,a,b,c,arr[i+5],12,1200080426); c=md5ff(c,d,a,b,arr[i+6],17,-1473231341); b=md5ff(b,c,d,a,arr[i+7],22,-45705983);
    a=md5ff(a,b,c,d,arr[i+8],7,1770035416); d=md5ff(d,a,b,c,arr[i+9],12,-1958414417); c=md5ff(c,d,a,b,arr[i+10],17,-42063); b=md5ff(b,c,d,a,arr[i+11],22,-1990404162);
    a=md5ff(a,b,c,d,arr[i+12],7,1804603682); d=md5ff(d,a,b,c,arr[i+13],12,-40341101); c=md5ff(c,d,a,b,arr[i+14],17,-1502002290); b=md5ff(b,c,d,a,arr[i+15],22,1236535329);
    a=md5gg(a,b,c,d,arr[i+1],5,-165796510); d=md5gg(d,a,b,c,arr[i+6],9,-1069501632); c=md5gg(c,d,a,b,arr[i+11],14,643717713); b=md5gg(b,c,d,a,arr[i],20,-373897302);
    a=md5gg(a,b,c,d,arr[i+5],5,-701558691); d=md5gg(d,a,b,c,arr[i+10],9,38016083); c=md5gg(c,d,a,b,arr[i+15],14,-660478335); b=md5gg(b,c,d,a,arr[i+4],20,-405537848);
    a=md5gg(a,b,c,d,arr[i+9],5,568446438); d=md5gg(d,a,b,c,arr[i+14],9,-1019803690); c=md5gg(c,d,a,b,arr[i+3],14,-187363961); b=md5gg(b,c,d,a,arr[i+8],20,1163531501);
    a=md5gg(a,b,c,d,arr[i+13],5,-1444681467); d=md5gg(d,a,b,c,arr[i+2],9,-51403784); c=md5gg(c,d,a,b,arr[i+7],14,1735328473); b=md5gg(b,c,d,a,arr[i+12],20,-1926607734);
    a=md5hh(a,b,c,d,arr[i+5],4,-378558); d=md5hh(d,a,b,c,arr[i+8],11,-2022574463); c=md5hh(c,d,a,b,arr[i+11],16,1839030562); b=md5hh(b,c,d,a,arr[i+14],23,-35309556);
    a=md5hh(a,b,c,d,arr[i+1],4,-1530992060); d=md5hh(d,a,b,c,arr[i+4],11,1272893353); c=md5hh(c,d,a,b,arr[i+7],16,-155497632); b=md5hh(b,c,d,a,arr[i+10],23,-1094730640);
    a=md5hh(a,b,c,d,arr[i+13],4,681279174); d=md5hh(d,a,b,c,arr[i],11,-358537222); c=md5hh(c,d,a,b,arr[i+3],16,-722521979); b=md5hh(b,c,d,a,arr[i+6],23,76029189);
    a=md5hh(a,b,c,d,arr[i+9],4,-640364487); d=md5hh(d,a,b,c,arr[i+12],11,-421815835); c=md5hh(c,d,a,b,arr[i+15],16,530742520); b=md5hh(b,c,d,a,arr[i+2],23,-995338651);
    a=md5ii(a,b,c,d,arr[i],6,-198630844); d=md5ii(d,a,b,c,arr[i+7],10,1126891415); c=md5ii(c,d,a,b,arr[i+14],15,-1416354905); b=md5ii(b,c,d,a,arr[i+5],21,-57434055);
    a=md5ii(a,b,c,d,arr[i+12],6,1700485571); d=md5ii(d,a,b,c,arr[i+3],10,-1894986606); c=md5ii(c,d,a,b,arr[i+10],15,-1051523); b=md5ii(b,c,d,a,arr[i+1],21,-2054922799);
    a=md5ii(a,b,c,d,arr[i+8],6,1873313359); d=md5ii(d,a,b,c,arr[i+15],10,-30611744); c=md5ii(c,d,a,b,arr[i+6],15,-1560198380); b=md5ii(b,c,d,a,arr[i+13],21,1309151649);
    a=md5ii(a,b,c,d,arr[i+4],6,-145523070); d=md5ii(d,a,b,c,arr[i+11],10,-1120210379); c=md5ii(c,d,a,b,arr[i+2],15,718787259); b=md5ii(b,c,d,a,arr[i+9],21,-343485551);
    a=safeAdd(a,oA); b=safeAdd(b,oB); c=safeAdd(c,oC); d=safeAdd(d,oD);
  }
  function intToHex(num) { let hex=''; for(let i=0;i<4;i++){hex+=('0'+((num>>>(i*8))&0xFF).toString(16)).slice(-2);} return hex; }
  return intToHex(a)+intToHex(b)+intToHex(c)+intToHex(d);
}

// Morse code
const MORSE_MAP = {
  A:'.-', B:'-...', C:'-.-.', D:'-..', E:'.', F:'..-.', G:'--.', H:'....', I:'..', J:'.---',
  K:'-.-', L:'.-..', M:'--', N:'-.', O:'---', P:'.--.', Q:'--.-', R:'.-.', S:'...', T:'-',
  U:'..-', V:'...-', W:'.--', X:'-..-', Y:'-.--', Z:'--..',
  '0':'-----','1':'.----','2':'..---','3':'...--','4':'....-','5':'.....',
  '6':'-....','7':'--...','8':'---..','9':'----.',
  '.':'.-.-.-',',':'--..--','?':'..--..','!':'-.-.--','/':'-..-.','@':'.--.-.'
};
const MORSE_REVERSE = Object.fromEntries(Object.entries(MORSE_MAP).map(([k,v])=>[v,k]));

function textToMorse(text) {
  return text.toUpperCase().split('').map(c => c === ' ' ? '/' : (MORSE_MAP[c] || '')).join(' ');
}
function morseToText(morse) {
  return morse.split(' / ').map(word =>
    word.split(' ').map(code => MORSE_REVERSE[code] || '?').join('')
  ).join(' ');
}

// ROT13
function rot13(str) {
  return str.replace(/[a-zA-Z]/g, c => {
    const base = c < 'a' ? 65 : 97;
    return String.fromCharCode(((c.charCodeAt(0) - base + 13) % 26) + base);
  });
}

// Caesar
function caesar(str, shift) {
  shift = ((shift % 26) + 26) % 26;
  return str.replace(/[a-zA-Z]/g, c => {
    const base = c < 'a' ? 65 : 97;
    return String.fromCharCode(((c.charCodeAt(0) - base + shift) % 26) + base);
  });
}

// Lorem ipsum paragraphs
const LOREM_WORDS = 'lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur excepteur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est laborum'.split(' ');

function lorem(paragraphs, wordsPerPara) {
  let result = [];
  for (let p = 0; p < paragraphs; p++) {
    let words = [];
    for (let w = 0; w < wordsPerPara; w++) words.push(LOREM_WORDS[Math.floor(Math.random()*LOREM_WORDS.length)]);
    words[0] = words[0].charAt(0).toUpperCase() + words[0].slice(1);
    result.push(words.join(' ') + '.');
  }
  return result.join('\n\n');
}

// Subnet Calculator helper
function ipToInt(ip) { return ip.split('.').reduce((acc, o) => (acc << 8) | parseInt(o), 0) >>> 0; }
function intToIp(n) { return [(n>>>24)&255,(n>>>16)&255,(n>>>8)&255,n&255].join('.'); }

function subnetCalc(ip, cidr) {
  const mask = cidr === 0 ? 0 : (0xFFFFFFFF << (32-cidr)) >>> 0;
  const ipInt = ipToInt(ip);
  const network = (ipInt & mask) >>> 0;
  const broadcast = (network | ~mask) >>> 0;
  return {
    network: intToIp(network),
    broadcast: intToIp(broadcast),
    mask: intToIp(mask),
    first: intToIp(network + 1),
    last: intToIp(broadcast - 1),
    hosts: Math.max(0, broadcast - network - 1),
  };
}
