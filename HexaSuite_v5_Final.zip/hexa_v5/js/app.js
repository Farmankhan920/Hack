// HexaSuite v4.0 — app.js

const TOOLS = [
  // ── Encoding ──────────────────────────────────────────────────
  {id:1,  name:"Text → Hex",        file:"text-to-hex.html",       cat:"encoding", icon:"🔡"},
  {id:2,  name:"Hex → Text",        file:"hex-to-text.html",       cat:"encoding", icon:"🔢"},
  {id:3,  name:"Text → Base64",     file:"base64-encode.html",     cat:"encoding", icon:"📦"},
  {id:4,  name:"Base64 → Text",     file:"base64-decode.html",     cat:"encoding", icon:"📬"},
  {id:5,  name:"URL Encode",        file:"url-encode.html",        cat:"encoding", icon:"🔗"},
  {id:6,  name:"URL Decode",        file:"url-decode.html",        cat:"encoding", icon:"🔓"},
  {id:7,  name:"HTML Encode",       file:"html-encode.html",       cat:"encoding", icon:"📝"},
  {id:8,  name:"HTML Decode",       file:"html-decode.html",       cat:"encoding", icon:"📄"},
  {id:9,  name:"Binary → Text",     file:"binary-to-text.html",    cat:"encoding", icon:"01️⃣"},
  {id:10, name:"Text → Binary",     file:"text-to-binary.html",    cat:"encoding", icon:"🔲"},
  {id:11, name:"ASCII → Text",      file:"ascii-to-text.html",     cat:"encoding", icon:"🅰️"},
  {id:12, name:"Text → ASCII",      file:"text-to-ascii.html",     cat:"encoding", icon:"🔣"},
  {id:13, name:"Morse Encode",      file:"morse-encode.html",      cat:"encoding", icon:"📡"},
  {id:14, name:"Morse Decode",      file:"morse-decode.html",      cat:"encoding", icon:"📻"},
  {id:15, name:"ROT13",             file:"rot13.html",             cat:"encoding", icon:"🔄"},
  // ── Cryptography ──────────────────────────────────────────────
  {id:16, name:"SHA-1 Hash",        file:"sha1.html",              cat:"crypto",   icon:"🔐"},
  {id:17, name:"SHA-256 Hash",      file:"sha256.html",            cat:"crypto",   icon:"🔑"},
  {id:18, name:"SHA-512 Hash",      file:"sha512.html",            cat:"crypto",   icon:"🗝️"},
  {id:19, name:"MD5 Hash",          file:"md5.html",               cat:"crypto",   icon:"🧮"},
  {id:20, name:"HMAC Gen",          file:"hmac.html",              cat:"crypto",   icon:"🛡️"},
  {id:21, name:"Password Gen",      file:"password-gen.html",      cat:"crypto",   icon:"🔒"},
  {id:22, name:"Password Strength", file:"password-strength.html", cat:"crypto",   icon:"💪"},
  {id:23, name:"Token Generator",   file:"token-gen.html",         cat:"crypto",   icon:"🎟️"},
  {id:24, name:"UUID Generator",    file:"uuid-gen.html",          cat:"crypto",   icon:"🆔"},
  {id:25, name:"Caesar Cipher",     file:"caesar.html",            cat:"crypto",   icon:"🏛️"},
  // ── Developer ─────────────────────────────────────────────────
  {id:26, name:"JSON Formatter",    file:"json-formatter.html",    cat:"developer",icon:"{ }"},
  {id:27, name:"JSON Minifier",     file:"json-minifier.html",     cat:"developer",icon:"📉"},
  {id:28, name:"HTML Formatter",    file:"html-formatter.html",    cat:"developer",icon:"🌐"},
  {id:29, name:"CSS Formatter",     file:"css-formatter.html",     cat:"developer",icon:"🎨"},
  {id:30, name:"JS Formatter",      file:"js-formatter.html",      cat:"developer",icon:"⚡"},
  {id:31, name:"Regex Tester",      file:"regex-tester.html",      cat:"developer",icon:"🔍"},
  {id:32, name:"Color Picker",      file:"color-picker.html",      cat:"developer",icon:"🎨"},
  {id:33, name:"HEX → RGB",         file:"hex-to-rgb.html",        cat:"developer",icon:"🟥"},
  {id:34, name:"RGB → HEX",         file:"rgb-to-hex.html",        cat:"developer",icon:"🔵"},
  {id:35, name:"Timestamp → Date",  file:"timestamp-to-date.html", cat:"developer",icon:"📅"},
  {id:36, name:"Date → Timestamp",  file:"date-to-timestamp.html", cat:"developer",icon:"⏱️"},
  {id:37, name:"Lorem Ipsum",       file:"lorem-ipsum.html",       cat:"developer",icon:"📋"},
  {id:38, name:"Word Counter",      file:"word-counter.html",      cat:"developer",icon:"🔢"},
  {id:39, name:"Case Converter",    file:"case-converter.html",    cat:"developer",icon:"Aa"},
  {id:40, name:"Diff Checker",      file:"diff-checker.html",      cat:"developer",icon:"🔀"},
  {id:41, name:"JWT Decoder",       file:"jwt-decoder.html",       cat:"developer",icon:"🪪"},
  {id:42, name:"JWT Encoder",       file:"jwt-encoder.html",       cat:"developer",icon:"🔏"},
  {id:43, name:"CSV to JSON",       file:"csv-to-json.html",       cat:"developer",icon:"📊"},
  {id:44, name:"JSON to CSV",       file:"json-to-csv.html",       cat:"developer",icon:"📈"},
  {id:45, name:"XML Formatter",     file:"xml-formatter.html",     cat:"developer",icon:"📜"},
  {id:46, name:"Markdown Preview",  file:"markdown-preview.html",  cat:"developer",icon:"✍️"},
  {id:47, name:"Number Base Conv",  file:"base-converter.html",    cat:"developer",icon:"🔢"},
  {id:48, name:"Cron Expression",   file:"cron-parser.html",       cat:"developer",icon:"⏰"},
  // ── Network ───────────────────────────────────────────────────
  {id:49, name:"IP Extractor",      file:"ip-extractor.html",      cat:"network",  icon:"🌐"},
  {id:50, name:"Header Viewer",     file:"header-viewer.html",     cat:"network",  icon:"📨"},
  {id:51, name:"Subnet Calc",       file:"subnet-calc.html",       cat:"network",  icon:"🕸️"},
  {id:52, name:"URL Parser",        file:"url-parser.html",        cat:"network",  icon:"🔗"},
  {id:53, name:"Query Parser",      file:"query-parser.html",      cat:"network",  icon:"❓"},
  {id:54, name:"User-Agent",        file:"user-agent.html",        cat:"network",  icon:"🕵️"},
  {id:55, name:"IP Generator",      file:"ip-gen.html",            cat:"network",  icon:"📡"},
  {id:56, name:"MAC Generator",     file:"mac-gen.html",           cat:"network",  icon:"💻"},
  {id:57, name:"DNS Lookup",        file:"dns-lookup.html",        cat:"network",  icon:"🔎"},
  {id:58, name:"HTTP Status Codes", file:"http-status.html",       cat:"network",  icon:"📟"},
  // ── Text ──────────────────────────────────────────────────────
  {id:59, name:"Remove Dupes",      file:"remove-dupes.html",      cat:"text",     icon:"🗑️"},
  {id:60, name:"Sort Lines",        file:"sort-lines.html",        cat:"text",     icon:"↕️"},
  {id:61, name:"Reverse Text",      file:"reverse-text.html",      cat:"text",     icon:"🔃"},
  {id:62, name:"Remove Spaces",     file:"remove-spaces.html",     cat:"text",     icon:"✂️"},
  {id:63, name:"Slug Generator",    file:"slug-gen.html",          cat:"text",     icon:"🐌"},
  {id:64, name:"Text Cleaner",      file:"text-cleaner.html",      cat:"text",     icon:"🧹"},
  {id:65, name:"Remove Specials",   file:"remove-specials.html",   cat:"text",     icon:"🚮"},
  {id:66, name:"Text to Speech",    file:"tts.html",               cat:"text",     icon:"🔊"},
  {id:67, name:"Speech to Text",    file:"stt.html",               cat:"text",     icon:"🎤"},
  {id:68, name:"Char Counter",      file:"char-counter.html",      cat:"text",     icon:"🔢"},
  {id:69, name:"Find & Replace",    file:"find-replace.html",      cat:"text",     icon:"🔎"},
  {id:70, name:"Text Encryptor",    file:"text-encrypt.html",      cat:"text",     icon:"🔐"},
  {id:71, name:"Palindrome Check",  file:"palindrome.html",        cat:"text",     icon:"🪞"},
  {id:72, name:"Text Stats",        file:"text-stats.html",        cat:"text",     icon:"📊"},
  // ── Math ──────────────────────────────────────────────────────
  {id:73, name:"BMI Calculator",    file:"bmi.html",               cat:"math",     icon:"⚖️"},
  {id:74, name:"Age Calculator",    file:"age-calc.html",          cat:"math",     icon:"🎂"},
  {id:75, name:"EMI Calculator",    file:"emi-calc.html",          cat:"math",     icon:"💰"},
  {id:76, name:"Unit Converter",    file:"unit-converter.html",    cat:"math",     icon:"📐"},
  {id:77, name:"Percentage Calc",   file:"percentage-calc.html",   cat:"math",     icon:"%"},
  {id:78, name:"Random Number",     file:"random-num.html",        cat:"math",     icon:"🎲"},
  {id:79, name:"Stopwatch",         file:"stopwatch.html",         cat:"math",     icon:"⏱️"},
  {id:80, name:"Countdown Timer",   file:"countdown.html",         cat:"math",     icon:"⏳"},
  {id:81, name:"File Size Conv",    file:"file-size.html",         cat:"math",     icon:"💾"},
  {id:82, name:"Tip Calculator",    file:"tip-calc.html",          cat:"math",     icon:"🍽️"},
  {id:83, name:"Discount Calc",     file:"discount-calc.html",     cat:"math",     icon:"🏷️"},
  {id:84, name:"Interest Calc",     file:"interest-calc.html",     cat:"math",     icon:"📈"},
  {id:85, name:"Number Facts",      file:"number-facts.html",      cat:"math",     icon:"🔢"},
  // ── Generators ────────────────────────────────────────────────
  {id:86, name:"QR Generator",      file:"qr-gen.html",            cat:"generator",icon:"📱"},
  {id:87, name:"Barcode Gen",       file:"barcode-gen.html",       cat:"generator",icon:"⊟"},
  {id:88, name:"TODO List",         file:"todo.html",              cat:"generator",icon:"✅"},
  {id:89, name:"Notes Pad",         file:"notes.html",             cat:"generator",icon:"📒"},
  {id:90, name:"Clipboard Mgr",     file:"clipboard-mgr.html",     cat:"generator",icon:"📋"},
  {id:91, name:"Color Palette",     file:"color-palette.html",     cat:"generator",icon:"🎨"},
  {id:92, name:"Gradient Gen",      file:"gradient-gen.html",      cat:"generator",icon:"🌈"},
  {id:93, name:"Avatar Gen",        file:"avatar-gen.html",        cat:"generator",icon:"👤"},
  {id:94, name:"Fake Data Gen",     file:"fake-data.html",         cat:"generator",icon:"🃏"},
  {id:95, name:"Contract Template", file:"contract-tmpl.html",     cat:"generator",icon:"📃"},
  // ── Image ─────────────────────────────────────────────────────
  {id:96, name:"Image Base64",      file:"img-base64.html",        cat:"image",    icon:"🖼️"},
  {id:97, name:"Image Color Pick",  file:"img-color.html",         cat:"image",    icon:"🎨"},
  {id:98, name:"ASCII Art Gen",     file:"ascii-art.html",         cat:"image",    icon:"🖼️"},
  {id:99, name:"Screen Resolution", file:"screen-info.html",       cat:"image",    icon:"🖥️"},
  {id:100,name:"Favicon Gen",       file:"favicon-gen.html",       cat:"image",    icon:"⭐"},
  // ── Ethical Hacking ───────────────────────────────────────────
  {id:101,name:"Hash Cracker",      file:"hash-cracker.html",      cat:"hacking",  icon:"🔓"},
  {id:102,name:"XSS Payload Gen",   file:"xss-payload.html",       cat:"hacking",  icon:"💉"},
  {id:103,name:"SQL Injection",     file:"sqli-payload.html",      cat:"hacking",  icon:"🗄️"},
  {id:104,name:"Port Scanner",      file:"port-scanner.html",      cat:"hacking",  icon:"🔭"},
  {id:105,name:"OSINT Finder",      file:"osint.html",             cat:"hacking",  icon:"🕵️"},
  {id:106,name:"CIDR Calc",         file:"cidr-calc.html",         cat:"hacking",  icon:"🌐"},
  {id:107,name:"Payload Encoder",   file:"payload-encoder.html",   cat:"hacking",  icon:"🧬"},
  {id:108,name:"CVE Lookup",        file:"cve-lookup.html",        cat:"hacking",  icon:"🛡️"},
  {id:109,name:"Password Audit",    file:"password-audit.html",    cat:"hacking",  icon:"🔐"},
  {id:110,name:"Wordlist Gen",      file:"wordlist-gen.html",      cat:"hacking",  icon:"📝"},
  {id:111,name:"Encoder Chain",     file:"encoder-chain.html",     cat:"hacking",  icon:"⛓️"},
  {id:112,name:"HTTP Headers Sec",  file:"http-security.html",     cat:"hacking",  icon:"🔒"},
  {id:113,name:"SSL Cert Checker",  file:"ssl-checker.html",       cat:"hacking",  icon:"📜"},
  {id:114,name:"Email Header Anal", file:"email-header.html",      cat:"hacking",  icon:"📧"},
  {id:115,name:"Network Calc",      file:"network-calc.html",      cat:"hacking",  icon:"🕸️"},
  // NEW HACKING TOOLS
  {id:116,name:"LFI Path Tester",   file:"lfi-paths.html",         cat:"hacking",  icon:"📂"},
  {id:117,name:"CSRF PoC Gen",      file:"csrf-poc.html",          cat:"hacking",  icon:"🎯"},
  {id:118,name:"Subdomain Finder",  file:"subdomain-finder.html",  cat:"hacking",  icon:"🔍"},
  {id:119,name:"Google Dork Gen",   file:"dork-gen.html",          cat:"hacking",  icon:"🔎"},
  {id:120,name:"Reverse Shell Gen", file:"revshell-gen.html",      cat:"hacking",  icon:"🐚"},
  {id:121,name:"HTTP Request Forge",file:"http-forge.html",        cat:"hacking",  icon:"⚒️"},
  {id:122,name:"JWT Cracker",       file:"jwt-crack.html",         cat:"hacking",  icon:"🪪"},
  {id:123,name:"Brute Force Dict",  file:"brute-dict.html",        cat:"hacking",  icon:"🔨"},
  {id:124,name:"SSRF Payload Gen",  file:"ssrf-payload.html",      cat:"hacking",  icon:"🌊"},
  {id:125,name:"Path Traversal",    file:"path-traversal.html",    cat:"hacking",  icon:"🛤️"},
  {id:126,name:"XXE Payload Gen",   file:"xxe-payload.html",       cat:"hacking",  icon:"💣"},
  {id:127,name:"SSTI Payload Gen",  file:"ssti-payload.html",      cat:"hacking",  icon:"🧪"},
  {id:128,name:"Nmap Cheatsheet",   file:"nmap-cheatsheet.html",   cat:"hacking",  icon:"📋"},
  {id:129,name:"Recon Checklist",   file:"recon-checklist.html",   cat:"hacking",  icon:"✅"},
  {id:130,name:"WAF Bypass",        file:"waf-bypass.html",        cat:"hacking",  icon:"🛡️"},
  {id:131,name:"Hash Identifier",   file:"hash-identifier.html",   cat:"hacking",  icon:"🔍"},
  {id:132,name:"Encoding Detector", file:"encoding-detect.html",   cat:"hacking",  icon:"🧠"},
  {id:133,name:"Cookie Analyzer",   file:"cookie-analyzer.html",   cat:"hacking",  icon:"🍪"},
  {id:134,name:"Privilege Escal",   file:"privesc-checklist.html", cat:"hacking",  icon:"⬆️"},
  {id:135,name:"Metasploit Ref",    file:"metasploit-ref.html",    cat:"hacking",  icon:"💀"},
  // ── New Hacking Tools v5 ─────────────────────────────────────
  {id:136,name:"ARP Spoof Ref",     file:"arp-spoof.html",         cat:"hacking",  icon:"🕵️"},
  {id:137,name:"Hydra Builder",     file:"hydra-builder.html",     cat:"hacking",  icon:"🐉"},
  {id:138,name:"Shodan Dorks",      file:"shodan-dork.html",       cat:"hacking",  icon:"👁️"},
  {id:139,name:"Open Redirect",     file:"open-redirect.html",     cat:"hacking",  icon:"↪️"},
  {id:140,name:"Cmd Injection",     file:"cmdi-payload.html",      cat:"hacking",  icon:"💻"},
  {id:141,name:"Nikto Builder",     file:"nikto-builder.html",     cat:"hacking",  icon:"🕷️"},
  {id:142,name:"DNS Zone Xfer",     file:"dns-zone-transfer.html", cat:"hacking",  icon:"🔀"},
  {id:143,name:"IDOR Tester",       file:"idor-tester.html",       cat:"hacking",  icon:"🔑"},
  {id:144,name:"Burp Suite Tips",   file:"burp-cheatsheet.html",   cat:"hacking",  icon:"🧰"},
  {id:145,name:"Phishing Tmpl",     file:"phishing-tmpl.html",     cat:"hacking",  icon:"🎣"},
  {id:146,name:"WiFi Security",     file:"wifi-toolkit.html",      cat:"hacking",  icon:"📶"},
  {id:147,name:"APK Tester",        file:"apk-tester.html",        cat:"hacking",  icon:"📱"},
  {id:148,name:"CTF Crypto",        file:"ctf-crypto.html",        cat:"hacking",  icon:"🏆"},
  {id:149,name:"SQLMap Builder",    file:"sqlmap-builder.html",    cat:"hacking",  icon:"🗄️"},
  {id:150,name:"Dir Brute Force",   file:"dir-brute.html",         cat:"hacking",  icon:"📁"},
  {id:151,name:"Buffer Overflow",   file:"bof-ref.html",           cat:"hacking",  icon:"💥"},
  {id:152,name:"Netcat Toolkit",    file:"nc-toolkit.html",        cat:"hacking",  icon:"🔌"},
  {id:153,name:"Pentest Report",    file:"pentest-report.html",    cat:"hacking",  icon:"📝"},
];

const CAT_COLORS = {
  encoding:'icon-enc', crypto:'icon-crypt', developer:'icon-dev',
  network:'icon-net',  text:'icon-text',    math:'icon-math',
  generator:'icon-gen', image:'icon-img',   hacking:'icon-hack',
};

const CAT_LABELS = {
  all:'All', encoding:'Encoding', crypto:'Crypto', developer:'Dev Utils',
  network:'Network', text:'Text', math:'Math', generator:'Generators',
  image:'Image', hacking:'Hacking',
};

const CAT_ICONS = {
  all:'⬡', encoding:'🔡', crypto:'🔐', developer:'⚡',
  network:'🌐', text:'📝', math:'📐', generator:'🛠️',
  image:'🖼️', hacking:'☠️',
};

// ── STATE (persistent via sessionStorage to survive tool navigation) ──
let state = {
  cat: 'all',
  search: '',
  page: 'home',
  scrollY: 0,
};

function loadState() {
  try {
    const s = sessionStorage.getItem('hs_state');
    if (s) {
      const parsed = JSON.parse(s);
      state = { ...state, ...parsed };
    }
  } catch(e) {}
}

function saveState() {
  try {
    // save scroll position
    const sa = document.getElementById('scroll-area');
    if (sa) state.scrollY = sa.scrollTop;
    sessionStorage.setItem('hs_state', JSON.stringify(state));
  } catch(e) {}
}

let favorites = [];
let recentTools = [];
let settings = {};

// ── Init ──────────────────────────────────────────────────────────
function init() {
  loadStorage();
  loadState();
  applyTheme();
  applySettings();
  renderCategories('categories');
  renderCategories('tools-categories');

  // Restore previous state (category + search after returning from tool)
  if (state.search) {
    const inp = document.getElementById('search-input');
    if (inp) inp.value = state.search;
  }
  currentCat = state.cat || 'all';

  renderTools();
  renderFavs();
  renderRecent();
  updateStats();
  setupSearch();
  setupDarkToggle();
  renderDashboard();

  // Restore page
  const restorePage = state.page || 'home';
  _showPageInternal(restorePage, true);

  // Restore scroll
  setTimeout(() => {
    const sa = document.getElementById('scroll-area');
    if (sa && state.scrollY) sa.scrollTop = state.scrollY;
  }, 80);

  // Push initial history state
  history.replaceState({ page: restorePage, cat: state.cat, search: state.search }, '');

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('service-worker.js').catch(()=>{});
  }
  document.body.classList.add('fade-in');
}

// ── Mobile back button fix ─────────────────────────────────────────
window.addEventListener('popstate', function(e) {
  if (e.state && e.state.page) {
    if (e.state.cat) currentCat = e.state.cat;
    if (e.state.search !== undefined) {
      const inp = document.getElementById('search-input');
      if (inp) inp.value = e.state.search || '';
      searchQuery = e.state.search || '';
    }
    _showPageInternal(e.state.page, true);
    if (e.state.cat) {
      renderCategories();
      renderTools();
    }
  } else {
    _showPageInternal('home', true);
  }
});

let currentCat = 'all';
let searchQuery = '';
let currentPage = 'home';

// ── Storage ────────────────────────────────────────────────────────
function loadStorage() {
  try {
    favorites = JSON.parse(localStorage.getItem('hs_favs') || '[]');
    recentTools = JSON.parse(localStorage.getItem('hs_recent') || '[]');
    settings = JSON.parse(localStorage.getItem('hs_settings') || '{}');
    const theme = localStorage.getItem('hs_theme');
    if (theme === 'light') document.documentElement.setAttribute('data-theme','light');
  } catch(e) { favorites=[]; recentTools=[]; settings={}; }
}

function saveStorage() {
  try {
    localStorage.setItem('hs_favs', JSON.stringify(favorites));
    localStorage.setItem('hs_recent', JSON.stringify(recentTools));
    localStorage.setItem('hs_settings', JSON.stringify(settings));
  } catch(e) {}
}

// ── Theme ──────────────────────────────────────────────────────────
function applyTheme() {
  const isLight = document.documentElement.getAttribute('data-theme') === 'light';
  const btn = document.getElementById('darkToggle');
  const chk = document.getElementById('darkToggleSettings');
  if (btn) btn.textContent = isLight ? '🌙' : '☀️';
  if (chk) chk.checked = isLight;
}

function toggleDark() {
  const isLight = document.documentElement.getAttribute('data-theme') === 'light';
  if (isLight) {
    document.documentElement.removeAttribute('data-theme');
    localStorage.setItem('hs_theme','dark');
  } else {
    document.documentElement.setAttribute('data-theme','light');
    localStorage.setItem('hs_theme','light');
  }
  applyTheme();
  showToast(isLight ? '🌙 Dark mode' : '☀️ Light mode');
}

function setupDarkToggle() {
  const btn = document.getElementById('darkToggle');
  if (btn) btn.addEventListener('click', toggleDark);
}

// ── Settings ───────────────────────────────────────────────────────
function applySettings() {
  const cols = settings.gridCols || 2;
  document.querySelectorAll('.tools-grid').forEach(g => {
    g.style.gridTemplateColumns = `repeat(${cols}, 1fr)`;
  });
  if (settings.accentColor) {
    document.documentElement.style.setProperty('--primary', settings.accentColor);
    document.documentElement.style.setProperty('--primary-glow', `0 0 20px ${settings.accentColor}44`);
    document.documentElement.style.setProperty('--primary-dim', `${settings.accentColor}22`);
  }
  if (settings.fontSize) {
    document.querySelectorAll('.tool-name').forEach(el => el.style.fontSize = settings.fontSize + 'px');
    // update font tab buttons
    document.querySelectorAll('.font-tab-btn').forEach(b => {
      b.classList.toggle('active', parseInt(b.dataset.size) === settings.fontSize);
    });
    const lbl = document.getElementById('fontSizeLabel');
    const labels = { 12: 'Small (12px)', 14: 'Medium (14px)', 16: 'Large (16px)' };
    if (lbl) lbl.textContent = labels[settings.fontSize] || 'Medium (14px)';
  }
}

function setGrid(cols, btn) {
  document.querySelectorAll('.grid-tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.tools-grid').forEach(g => {
    g.style.gridTemplateColumns = `repeat(${cols}, 1fr)`;
  });
  settings.gridCols = cols;
  saveStorage();
}

// ── Pages ──────────────────────────────────────────────────────────
function showPage(page) {
  saveState();
  state.page = page;
  history.pushState({ page, cat: currentCat, search: searchQuery }, '');
  _showPageInternal(page, false);
}

function _showPageInternal(page, restore) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

  if (page === 'tools') {
    const pageEl = document.getElementById('page-tools');
    if (pageEl) pageEl.classList.add('active');
    const navEl = document.getElementById('nav-tools');
    if (navEl) navEl.classList.add('active');
    currentPage = 'tools';
    renderToolsPage();
  } else {
    const pageEl = document.getElementById('page-' + page);
    if (pageEl) pageEl.classList.add('active');
    const navEl = document.getElementById('nav-' + page);
    if (navEl) navEl.classList.add('active');
    currentPage = page;
  }

  if (page === 'home') renderDashboard();
  if (page === 'favs') renderFavs();
  if (page === 'recent') renderRecent();
  if (page === 'settings') { renderSettingsPage(); renderSettingsStats(); }

  if (!restore) {
    const sa = document.getElementById('scroll-area');
    if (sa) sa.scrollTop = 0;
  }
}

// ── Categories ─────────────────────────────────────────────────────
function renderCategories(containerId) {
  const id = containerId || 'categories';
  const el = document.getElementById(id);
  if (!el) return;
  el.innerHTML = Object.entries(CAT_LABELS).map(([k, v]) => {
    const count = k === 'all' ? TOOLS.length : TOOLS.filter(t => t.cat === k).length;
    const active = k === currentCat;
    return `<div class="cat-chip${active?' active':''}" data-cat="${k}" onclick="filterCat('${k}')">
      <span class="cat-chip-icon">${CAT_ICONS[k]||''}</span>
      <span>${v}</span>
      <span class="cat-chip-count">${count}</span>
    </div>`;
  }).join('');
  // Scroll active chip into view
  setTimeout(() => {
    const chip = el.querySelector('.cat-chip.active');
    if (chip) chip.scrollIntoView({ behavior:'smooth', block:'nearest', inline:'center' });
  }, 50);
}

function filterCat(cat) {
  currentCat = cat;
  state.cat = cat;
  renderCategories('categories');
  renderCategories('tools-categories');
  renderTools();
  // Update history state
  history.replaceState({ page: currentPage, cat, search: searchQuery }, '');
  // Scroll grid to top
  const sa = document.getElementById('scroll-area');
  if (sa) sa.scrollTop = 0;
}

// ── Tools Grid ─────────────────────────────────────────────────────
function renderTools() {
  const el = document.getElementById('tools-grid');
  const titleEl = document.getElementById('sectionTitle');
  if (!el) return;

  const filtered = TOOLS.filter(t =>
    (currentCat === 'all' || t.cat === currentCat) &&
    t.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const label = currentCat === 'all' ? '⬡ All Tools' : (CAT_ICONS[currentCat]||'') + ' ' + (CAT_LABELS[currentCat]||'Tools');
  if (titleEl) {
    titleEl.innerHTML = `${label} <span class="section-count" id="sectionCount">${filtered.length}</span>`;
  }

  if (!filtered.length) {
    el.innerHTML = '<div class="empty-state">🔍 No tools found</div>';
    return;
  }

  el.innerHTML = filtered.map((t, i) => buildCard(t, i)).join('');
  addRipple();
}

function buildCard(t, delay) {
  const isFav = favorites.includes(t.id);
  const isHack = t.cat === 'hacking';
  return `<div class="tool-card card-enter${isHack?' hack-card':''}" style="animation-delay:${Math.min(delay*0.02,0.4)}s" onclick="openTool('${t.file}',${t.id},'${t.cat}')">
    <div class="card-glow"></div>
    <button class="fav-btn${isFav?' active':''}" onclick="event.stopPropagation();toggleFav(${t.id},this)" title="Favorite">★</button>
    <div class="tool-icon ${CAT_COLORS[t.cat]||'icon-dev'}">${t.icon}</div>
    <div class="tool-name">${t.name}</div>
    <div class="tool-cat-label">${CAT_LABELS[t.cat]||t.cat}</div>
  </div>`;
}

function renderToolsPage() {
  renderCategories('tools-categories');
  renderTools();
}

function openTool(file, id, cat) {
  recentTools = [id, ...recentTools.filter(x => x !== id)].slice(0, 20);
  // Save current state so when user comes back, we restore category
  saveState();
  state.cat = currentCat;
  state.search = searchQuery;
  state.page = currentPage;
  saveState();
  saveStorage();
  updateStats();
  location.href = 'tools/' + file;
}

// ── Favorites ──────────────────────────────────────────────────────
function toggleFav(id, btn) {
  if (favorites.includes(id)) {
    favorites = favorites.filter(x => x !== id);
    btn.classList.remove('active');
    showToast('💔 Removed');
  } else {
    favorites.push(id);
    btn.classList.add('active');
    btn.classList.add('bounce');
    setTimeout(() => btn.classList.remove('bounce'), 500);
    showToast('⭐ Favorited!');
  }
  saveStorage();
  updateStats();
}

function renderFavs() {
  const el = document.getElementById('favs-grid');
  const countEl = document.getElementById('favCount');
  if (!el) return;
  const favTools = TOOLS.filter(t => favorites.includes(t.id));
  if (countEl) countEl.textContent = favTools.length;
  if (!favTools.length) {
    el.innerHTML = '<div style="grid-column:span 2"><div class="empty-state-full"><div class="esi">⭐</div><p>No favorites yet<br><small>Tap ★ on any tool card</small></p></div></div>';
    return;
  }
  el.innerHTML = favTools.map((t, i) => buildCard(t, i)).join('');
  addRipple();
}

function clearFavs() {
  if (confirm('Clear all favorites?')) {
    favorites = [];
    saveStorage();
    renderFavs();
    renderTools();
    updateStats();
    showToast('💔 Cleared');
  }
}

// ── Recent ─────────────────────────────────────────────────────────
function renderRecent() {
  const el = document.getElementById('recent-grid');
  const countEl = document.getElementById('recentCount');
  if (!el) return;
  const recentT = recentTools.map(id => TOOLS.find(t => t.id === id)).filter(Boolean);
  if (countEl) countEl.textContent = recentT.length;
  if (!recentT.length) {
    el.innerHTML = '<div style="grid-column:span 2"><div class="empty-state-full"><div class="esi">🕐</div><p>No recent tools<br><small>Open any tool to track it</small></p></div></div>';
    return;
  }
  el.innerHTML = recentT.map((t, i) => buildCard(t, i)).join('');
  addRipple();
}

function clearRecent() {
  if (confirm('Clear recent history?')) {
    recentTools = [];
    saveStorage();
    renderRecent();
    updateStats();
    showToast('🕐 Cleared');
  }
}

// ── Stats ──────────────────────────────────────────────────────────
function updateStats() {
  const statFavs = document.getElementById('statFavs');
  const statRecent = document.getElementById('statRecent');
  const statTotal = document.getElementById('statTotal');
  const navBadge = document.getElementById('navFavBadge');
  if (statFavs) statFavs.textContent = favorites.length;
  if (statRecent) statRecent.textContent = recentTools.length;
  if (statTotal) statTotal.textContent = TOOLS.length;
  if (navBadge) {
    navBadge.textContent = favorites.length;
    navBadge.classList.toggle('hidden', favorites.length === 0);
  }
}

// ── Dashboard ──────────────────────────────────────────────────────
function renderDashboard() {
  // Category breakdown cards
  const dashGrid = document.getElementById('dashGrid');
  if (dashGrid) {
    const cats = Object.entries(CAT_LABELS).filter(([k]) => k !== 'all');
    dashGrid.innerHTML = cats.map(([k, v]) => {
      const count = TOOLS.filter(t => t.cat === k).length;
      const colorClass = CAT_COLORS[k] || 'icon-dev';
      return `<div class="cat-grid-card card-enter" onclick="showPage('tools');filterCat('${k}')">
        <div class="cat-grid-icon ${colorClass}">${CAT_ICONS[k]||'🛠️'}</div>
        <div class="cat-grid-name">${v}</div>
        <div class="cat-grid-count">${count} tools</div>
      </div>`;
    }).join('');
  }

  // Quick access - show most recent 4 tools
  const quickEl = document.getElementById('quickAccess');
  const quickSection = document.getElementById('quickSection');
  if (quickEl && recentTools.length) {
    const recent4 = recentTools.slice(0, 4).map(id => TOOLS.find(t => t.id === id)).filter(Boolean);
    quickEl.innerHTML = recent4.map(t => `<div class="quick-tool-card" onclick="openTool('${t.file}',${t.id},'${t.cat}')">
      <span class="quick-tool-icon">${t.icon}</span>
      <div class="quick-tool-info">
        <div class="quick-tool-name">${t.name}</div>
        <div class="quick-tool-cat">${CAT_LABELS[t.cat]||t.cat}</div>
      </div>
    </div>`).join('');
    if (quickSection) quickSection.style.display = 'block';
  } else {
    if (quickSection) quickSection.style.display = 'none';
  }

  // Hacking highlight - show 4 random hacking tools
  const hackEl = document.getElementById('hackHighlight');
  if (hackEl) {
    const hackTools = TOOLS.filter(t => t.cat === 'hacking').slice(0, 4);
    hackEl.innerHTML = hackTools.map(t => `<div class="quick-tool-card" onclick="openTool('${t.file}',${t.id},'${t.cat}')">
      <span class="quick-tool-icon">${t.icon}</span>
      <div class="quick-tool-info">
        <div class="quick-tool-name">${t.name}</div>
        <div class="quick-tool-cat">Hacking</div>
      </div>
    </div>`).join('');
  }
}

// ── Search ─────────────────────────────────────────────────────────
function setupSearch() {
  const inp = document.getElementById('search-input');
  if (!inp) return;
  inp.addEventListener('input', e => {
    searchQuery = e.target.value;
    state.search = searchQuery;
    if (searchQuery && currentPage !== 'tools') {
      _showPageInternal('tools', false);
      history.pushState({ page: 'tools', cat: currentCat, search: searchQuery }, '');
    } else {
      history.replaceState({ page: currentPage, cat: currentCat, search: searchQuery }, '');
    }
    renderTools();
  });
}

// ── Ripple ─────────────────────────────────────────────────────────
function addRipple() {
  document.querySelectorAll('.tool-card').forEach(card => {
    card.addEventListener('click', function(e) {
      if (e.target.classList.contains('fav-btn')) return;
      const r = document.createElement('span');
      r.className = 'ripple';
      const rect = this.getBoundingClientRect();
      r.style.left = (e.clientX - rect.left) + 'px';
      r.style.top = (e.clientY - rect.top) + 'px';
      this.appendChild(r);
      setTimeout(() => r.remove(), 700);
    });
  });
}

// ── Toast ──────────────────────────────────────────────────────────
function showToast(msg) {
  document.querySelectorAll('.toast').forEach(t => t.remove());
  const t = document.createElement('div');
  t.className = 'toast'; t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 2300);
}

// ── Copy ───────────────────────────────────────────────────────────
function copyText(text) {
  if (!text) { showToast('❌ Nothing to copy'); return; }
  navigator.clipboard.writeText(text)
    .then(() => showToast('✅ Copied!'))
    .catch(() => {
      const ta = document.createElement('textarea');
      ta.value = text; document.body.appendChild(ta); ta.select();
      document.execCommand('copy'); ta.remove();
      showToast('✅ Copied!');
    });
}

// ── Settings Page ──────────────────────────────────────────────────
function renderSettingsPage() {
  const cols = settings.gridCols || 2;
  document.querySelectorAll('.grid-tab-btn').forEach(b => {
    b.classList.toggle('active', parseInt(b.dataset.cols) === cols);
  });
  const darkChk = document.getElementById('darkToggleSettings');
  if (darkChk) darkChk.checked = document.documentElement.getAttribute('data-theme') === 'light';
  const animChk = document.getElementById('animToggle');
  if (animChk) animChk.checked = !settings.noAnimations;
}

function toggleAnimations(chk) {
  settings.noAnimations = !chk.checked;
  saveStorage();
  showToast(chk.checked ? '✨ Animations on' : '🚫 Animations off');
}

function toggleCompact(chk) {
  settings.compactMode = chk.checked;
  saveStorage();
  document.querySelectorAll('.tool-card').forEach(c => {
    c.style.padding = chk.checked ? '10px 8px' : '';
  });
  showToast(chk.checked ? '📐 Compact mode on' : '📐 Compact mode off');
}

function toggleHideLabels(chk) {
  settings.hideLabels = chk.checked;
  saveStorage();
  document.querySelectorAll('.tool-cat-label').forEach(l => l.style.display = chk.checked ? 'none' : '');
  showToast(chk.checked ? '🏷️ Labels hidden' : '🏷️ Labels shown');
}

function setFontSize(size, btn) {
  document.querySelectorAll('.font-tab-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  document.querySelectorAll('.tool-name').forEach(el => el.style.fontSize = size + 'px');
  const labels = { 12: 'Small (12px)', 14: 'Medium (14px)', 16: 'Large (16px)' };
  const lbl = document.getElementById('fontSizeLabel');
  if (lbl) lbl.textContent = labels[size] || 'Medium';
  settings.fontSize = size;
  saveStorage();
  showToast('🔤 Font: ' + (labels[size] || size + 'px'));
}

function showChangelog() {
  showToast('v5: +13 hacking tools, copy buttons, FARMAN920 profile!');
}

function renderSettingsStats() {
  const b1 = document.getElementById('statUsedBadge');
  const b2 = document.getElementById('statFavsBadge');
  if (b1) b1.textContent = recentTools.length;
  if (b2) b2.textContent = favorites.length;
}

function setAccent(color) {
  settings.accentColor = color;
  document.documentElement.style.setProperty('--primary', color);
  document.documentElement.style.setProperty('--primary-glow', `0 0 20px ${color}44`);
  document.documentElement.style.setProperty('--primary-dim', `${color}22`);
  saveStorage();
  showToast('🎨 Accent updated');
}

function exportData() {
  const data = { favorites, recentTools, settings, version:'4.0', date:new Date().toISOString() };
  const blob = new Blob([JSON.stringify(data,null,2)],{type:'application/json'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'hexasuite-v4-backup.json';
  a.click();
  showToast('📦 Exported!');
}

function importData() {
  const input = document.createElement('input');
  input.type = 'file'; input.accept = '.json';
  input.onchange = e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const data = JSON.parse(ev.target.result);
        if (data.favorites) favorites = data.favorites;
        if (data.recentTools) recentTools = data.recentTools;
        if (data.settings) settings = data.settings;
        saveStorage();
        applySettings();
        updateStats();
        showToast('✅ Imported!');
      } catch { showToast('❌ Invalid file'); }
    };
    reader.readAsText(file);
  };
  input.click();
}

function resetAll() {
  if (confirm('Reset ALL data? Cannot be undone.')) {
    localStorage.clear();
    sessionStorage.clear();
    favorites=[]; recentTools=[]; settings={};
    saveStorage();
    updateStats();
    showToast('🔄 Reset complete');
    location.reload();
  }
}

function shareApp() {
  if (navigator.share) {
    navigator.share({title:'HexaSuite v4',text:'135+ hacking & dev tools, all offline!', url:location.href});
  } else {
    copyText(location.href);
    showToast('🔗 Link copied!');
  }
}

window.addEventListener('DOMContentLoaded', init);
