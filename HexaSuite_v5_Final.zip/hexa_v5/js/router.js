// router.js v4.0 — Mobile back button fixed
document.addEventListener('DOMContentLoaded', () => {
  document.body.classList.add('fade-in');
  const theme = localStorage.getItem('hs_theme');
  if (theme === 'light') document.documentElement.setAttribute('data-theme','light');
  // Push state on tool page so mobile back goes to app (not blank)
  if (location.pathname.includes('/tools/')) {
    history.replaceState({ isToolPage: true }, '');
    // Push another state: pressing back pops to here, then our popstate sends to index
    history.pushState({ goToIndex: true }, '');
  }
});

// Mobile back: when user presses hardware back on tool page, send them home
window.addEventListener('popstate', function(e) {
  if (location.pathname.includes('/tools/')) {
    location.href = '../index.html';
  }
});

function goBack() {
  const ref = document.referrer;
  if (ref && (ref.includes('index.html') || ref.endsWith('/') || !ref.includes('/tools/'))) {
    history.back();
  } else {
    location.href = '../index.html';
  }
}

function showToast(msg) {
  document.querySelectorAll('.toast').forEach(t => t.remove());
  const t = document.createElement('div');
  t.className = 'toast'; t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 2300);
}

function copyText(text) {
  if (!text || text === '') { showToast('❌ Nothing to copy'); return; }
  navigator.clipboard.writeText(text)
    .then(() => showToast('✅ Copied!'))
    .catch(() => {
      const ta = document.createElement('textarea');
      ta.value = text; document.body.appendChild(ta); ta.select();
      document.execCommand('copy'); ta.remove();
      showToast('✅ Copied!');
    });
}

function toggleDarkTool() {
  const isLight = document.documentElement.getAttribute('data-theme') === 'light';
  if (isLight) {
    document.documentElement.removeAttribute('data-theme');
    localStorage.setItem('hs_theme','dark');
  } else {
    document.documentElement.setAttribute('data-theme','light');
    localStorage.setItem('hs_theme','light');
  }
  const btn = document.getElementById('darkFloatBtn');
  if (btn) btn.textContent = document.documentElement.getAttribute('data-theme') === 'light' ? '🌙' : '☀️';
}

// Dark float button template for tool pages
function initToolPage() {
  const theme = localStorage.getItem('hs_theme');
  if (theme === 'light') document.documentElement.setAttribute('data-theme','light');
  const btn = document.getElementById('darkFloatBtn');
  if (btn) btn.textContent = theme === 'light' ? '🌙' : '☀️';
}
initToolPage();
